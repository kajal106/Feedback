<?php

namespace Kajal\Feedback\Controller\Adminhtml\Feedback;

/**
 * Class Delete
 * @package Kajal\Feedback\Controller\Adminhtml\Delete
 */
class Delete extends \Magento\Customer\Controller\Adminhtml\Group
{
    /**
     * @var
     */
    protected $_objectManager;

    /**
     * @return $this|void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            $model = $this->_objectManager->create('Kajal\Feedback\Model\Feedback')->getCollection()->addFieldToFilter('id', $id);
            try {
                foreach ($model as $value) {
                    if($id == $value->getData('id')){
                        $value->delete();
                    }
                }
                $this->messageManager->addSuccessMessage(__('You deleted Feedback.'));
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
        return $this->_redirect('feedback/feedback/index');
        return ;
    }
}

